/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/AnsysDev/examples/cicd/CruiseControl/KCG/config.txt
** Generation date: 2023-02-09T16:55:02
*************************************************************$ */
#ifndef _SaturateThrottle_CruiseControl_H_
#define _SaturateThrottle_CruiseControl_H_

#include "kcg_types.h"

/* =====================  no input structure  ====================== */

/* =====================  no output structure  ====================== */

/* CruiseControl::SaturateThrottle/ */
extern void SaturateThrottle_CruiseControl(
  /* ThrottleIn/, _L12/ */
  tPercent_Defs ThrottleIn,
  /* ThrottleOut/, _L8/ */
  tPercent_Defs *ThrottleOut,
  /* Saturate/, _L13/ */
  kcg_bool *Saturate);



#endif /* _SaturateThrottle_CruiseControl_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** SaturateThrottle_CruiseControl.h
** Generation date: 2023-02-09T16:55:02
*************************************************************$ */

