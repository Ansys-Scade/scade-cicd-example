/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/AnsysDev/examples/cicd/CruiseControl/KCG/config.txt
** Generation date: 2023-02-09T16:55:02
*************************************************************$ */

#include "kcg_consts.h"

/* Car::KTRANSM/ */
const array_float64_5 KTRANSM_Car = { kcg_lit_float64(4.75), kcg_lit_float64(
    2.68), kcg_lit_float64(1.87), kcg_lit_float64(1.42), kcg_lit_float64(
    1.17) };

/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** kcg_consts.c
** Generation date: 2023-02-09T16:55:02
*************************************************************$ */

