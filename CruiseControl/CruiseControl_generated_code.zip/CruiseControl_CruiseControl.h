/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** Command: kcg662.exe -config C:/AnsysDev/examples/cicd/CruiseControl/KCG/config.txt
** Generation date: 2023-02-09T16:55:02
*************************************************************$ */
#ifndef _CruiseControl_CruiseControl_H_
#define _CruiseControl_CruiseControl_H_

#include "kcg_types.h"
#include "CruiseSpeedMgt_CruiseControl.h"
#include "CruiseRegulation_CruiseControl.h"

/* ========================  input structure  ====================== */
typedef struct {
  kcg_bool /* On/ */ On;
  kcg_bool /* Off/ */ Off;
  kcg_bool /* Resume/ */ Resume;
  kcg_bool /* Set/ */ Set;
  kcg_bool /* QuickAccel/ */ QuickAccel;
  kcg_bool /* QuickDecel/ */ QuickDecel;
  tPercent_Defs /* Accel/ */ Accel;
  tPercent_Defs /* Brake/ */ Brake;
  tSpeed_Defs /* Speed/ */ Speed;
} inC_CruiseControl_CruiseControl;

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  tSpeed_Defs /* CruiseSpeed/ */ CruiseSpeed;
  tPercent_Defs /* ThrottleCmd/ */ ThrottleCmd;
  tCruiseState_Defs /* CruiseState/ */ CruiseState;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool init;
  kcg_bool init1;
  SSM_ST_SM2_Enabled_SM1 /* SM1:Enabled:SM2: */ SM2_state_nxt_Enabled_SM1;
  SSM_ST_SM3_Active_SM2_Enabled_SM1 /* SM1:Enabled:SM2:Active:SM3: */ SM3_state_nxt_Active_SM2_Enabled_SM1;
  SSM_ST_SM1 /* SM1: */ SM1_state_nxt;
  /* ---------------------  sub nodes' contexts  --------------------- */
  outC_CruiseRegulation_CruiseControl /* SM1:Enabled:SM2:Active:SM3:On:_L3=(CruiseControl::CruiseRegulation#2)/ */ Context_CruiseRegulation_2;
  outC_CruiseSpeedMgt_CruiseControl /* SM1:Enabled:_L8=(CruiseControl::CruiseSpeedMgt#1)/ */ Context_CruiseSpeedMgt_1;
  /* ----------------- no clocks of observable data ------------------ */
} outC_CruiseControl_CruiseControl;

/* ===========  node initialization and cycle functions  =========== */
/** "Title_1" {Title = " Title : Top Level of the Cruise Control application"} */
/** "Author_1" {Author = " Created by : ANSYS"} */
/** "Date_1" {Date = " $Date$"} */
/** "Version_1" {Version = " $Revision$"} */
/* CruiseControl::CruiseControl/ */
extern void CruiseControl_CruiseControl(
  inC_CruiseControl_CruiseControl *inC,
  outC_CruiseControl_CruiseControl *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void CruiseControl_reset_CruiseControl(
  outC_CruiseControl_CruiseControl *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void CruiseControl_init_CruiseControl(
  outC_CruiseControl_CruiseControl *outC);
#endif /* KCG_USER_DEFINED_INIT */



#endif /* _CruiseControl_CruiseControl_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6.2 (build i4) **********
** CruiseControl_CruiseControl.h
** Generation date: 2023-02-09T16:55:02
*************************************************************$ */

